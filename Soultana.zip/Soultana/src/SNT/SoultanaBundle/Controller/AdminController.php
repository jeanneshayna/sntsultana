<?php

namespace SNT\SoultanaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class AdminController extends Controller
{
    /**
     * @Route("user/add")
     */
    public function addAction()
    {
        return $this->render('SNTSoultanaBundle:Admin:add.html.twig', array(
            // ...
        ));
    }

}
