<?php

namespace SNT\SoultanaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Bien
 *
 * @ORM\Table(name="bien")
 * @ORM\Entity(repositoryClass="SNT\SoultanaBundle\Repository\BienRepository")
 */
class Bien
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nomBien", type="string", length=15)
     */
    private $nomBien;

    /**
     * @var bool
     *
     * @ORM\Column(name="etat", type="boolean")
     */
    private $etat;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     *  @ORM\OneToMany(targetEntity="SNT\SoultanaBundle\Entity\Image", mappedBy="biens")
     */
    private $images;
    /**
     *  @ORM\ManyToOne(targetEntity="SNT\SoultanaBundle\Entity\Localite", inversedBy="biens")
     */
    private $localites;
     /**
     *  @ORM\ManyToOne(targetEntity="SNT\SoultanaBundle\Entity\TypeBien", inversedBy="biens")
     */
    private $typebiens;
    /**
     *  @ORM\OneToMany(targetEntity="SNT\SoultanaBundle\Entity\Reservation", mappedBy="biens")
     */
    private $reservations;
    /**
     *  @ORM\OneToMany(targetEntity="SNT\SoultanaBundle\Entity\Contrat", mappedBy="biens")
     */
    private $contrats;

    /**
     * @var int
     *
     * @ORM\Column(name="prixLocation", type="integer")
     */
    private $prixLocation;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nomBien
     *
     * @param string $nomBien
     *
     * @return Bien
     */
    public function setNomBien($nomBien)
    {
        $this->nomBien = $nomBien;

        return $this;
    }

    /**
     * Get nomBien
     *
     * @return string
     */
    public function getNomBien()
    {
        return $this->nomBien;
    }

    /**
     * Set etat
     *
     * @param boolean $etat
     *
     * @return Bien
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return bool
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Bien
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set prixLocation
     *
     * @param integer $prixLocation
     *
     * @return Bien
     */
    public function setPrixLocation($prixLocation)
    {
        $this->prixLocation = $prixLocation;

        return $this;
    }

    /**
     * Get prixLocation
     *
     * @return int
     */
    public function getPrixLocation()
    {
        return $this->prixLocation;
    }
}

