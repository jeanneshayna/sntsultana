<?php

namespace SNT\SoultanaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TypeBien
 *
 * @ORM\Table(name="type_bien")
 * @ORM\Entity(repositoryClass="SNT\SoultanaBundle\Repository\TypeBienRepository")
 */
class TypeBien
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="libellé", type="string", length=50)
     */
    private $libellé;

    /**
     * @var string
     *
     * @ORM\Column(name="niveau", type="string", length=50)
     */
    private $niveau;
    /**
     *  @ORM\OneToMany(targetEntity="SNT\SoultanaBundle\Entity\Bien", mappedBy="typebiens")
     */
    private $biens;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set libellé
     *
     * @param string $libellé
     *
     * @return TypeBien
     */
    public function setLibellé($libellé)
    {
        $this->libellé = $libellé;

        return $this;
    }

    /**
     * Get libellé
     *
     * @return string
     */
    public function getLibellé()
    {
        return $this->libellé;
    }

    /**
     * Set niveau
     *
     * @param string $niveau
     *
     * @return TypeBien
     */
    public function setNiveau($niveau)
    {
        $this->niveau = $niveau;

        return $this;
    }

    /**
     * Get niveau
     *
     * @return string
     */
    public function getNiveau()
    {
        return $this->niveau;
    }
}

