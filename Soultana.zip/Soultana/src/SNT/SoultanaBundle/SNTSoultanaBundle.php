<?php

namespace SNT\SoultanaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SNTSoultanaBundle extends Bundle
{
}
